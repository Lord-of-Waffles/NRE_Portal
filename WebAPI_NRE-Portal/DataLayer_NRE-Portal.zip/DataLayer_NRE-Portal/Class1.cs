﻿namespace DataLayer_NRE_Portal
{
    public class Class1
    {

    }
}
